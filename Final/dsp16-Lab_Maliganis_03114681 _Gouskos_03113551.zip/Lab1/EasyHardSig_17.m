load('C:\Users\nmali\Documents\MATLAB\Lab1\my_touchtones.mat');
retEasySig = ttdecode(easySig)
%retHardSig = ttdecode(hardSig)